/* eslint-env node */
const express = require('express');
const router = express.Router();
const Call = require('../models/Call');
const { authMiddleware } = require('../middleware/auth');

// Get call history
router.get('/', authMiddleware, async (req, res) => {
    try {
        const history = await Call.getHistory(req.user.id);
        res.json(history);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'SERVER_ERROR' });
    }
});

// Initiate a call (metadata only, signaling via socket)
router.post('/', authMiddleware, async (req, res) => {
    try {
        const { receiverId, chatId, type } = req.body;
        const call = await Call.create({
            callerId: req.user.id,
            receiverId,
            chatId,
            type
        });
        res.json(call);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'SERVER_ERROR' });
    }
});

module.exports = router;
