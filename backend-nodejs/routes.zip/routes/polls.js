/* eslint-env node */
const express = require('express');
const router = express.Router();
const Poll = require('../models/Poll');
const { authMiddleware } = require('../middleware/auth');

// Create a poll
router.post('/', authMiddleware, async (req, res) => {
    try {
        const { question, options, allowMultiple } = req.body;
        const poll = await Poll.create({ question, options, allowMultiple });
        res.json(poll);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'SERVER_ERROR' });
    }
});

// Vote on a poll
router.post('/:id/vote', authMiddleware, async (req, res) => {
    try {
        const { optionId } = req.body;
        const poll = await Poll.vote(req.params.id, req.user.id, optionId);

        // Emit socket event for real-time update
        const io = req.app.get('io');
        if (io) {
            io.emit('poll:updated', { pollId: req.params.id, poll });
        }

        res.json(poll);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'SERVER_ERROR' });
    }
});

module.exports = router;
